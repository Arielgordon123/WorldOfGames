from Live import load_game, welcome

name = input("please enter your name: ")

print(welcome(name))

load_game()
